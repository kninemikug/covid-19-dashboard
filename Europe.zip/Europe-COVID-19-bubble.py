import pandas as pd
import plotly.graph_objects as go
import numpy as np

# 데이터 로드
latest_df = pd.read_csv('europe_covid_latest.csv')

# 데이터 필터링: 인구 100만 이상 국가만 선택
latest_filtered = latest_df[
    (latest_df['total_deaths_per_million'].notna()) & 
    (latest_df['population'] > 1000000)
].copy()

# 백신 접종률 계산
latest_filtered['people_vaccinated'] = latest_filtered['total_vaccinations'] * 0.6
latest_filtered['vaccination_rate'] = (
    latest_filtered['people_vaccinated'] / latest_filtered['population'] * 100
)

# 총 사망자 수 (천 단위)
latest_filtered['total_deaths_thousands'] = latest_filtered['total_deaths'] / 1000

# 버블 차트 생성
fig = go.Figure()

fig.add_trace(go.Scatter(
    x=latest_filtered['vaccination_rate'],           # X축: 백신 접종률 (%)
    y=latest_filtered['total_deaths_per_million'],   # Y축: 백만명당 총 사망자
    mode='markers',                                   # 마커 모드 (점)
    marker=dict(
        size=latest_filtered['population'] / 1000000,  # 버블 크기: 인구 (백만 단위)
        sizemode='diameter',                           # 크기 모드: 직경 기준
        sizeref=2. * max(latest_filtered['population'] / 1000000) / (60. ** 2),  # 크기 조정 참조값
        sizemin=4,                                     # 최소 버블 크기
        color=latest_filtered['total_deaths_per_million'],  # 색상: 사망률
        colorscale='Reds',                             # 색상 스케일: 빨간색 계열
        showscale=True,                                # 색상 바 표시
        colorbar=dict(
            title="백만명당<br>사망자",                # 색상 바 제목
            thickness=15,                              # 색상 바 두께
            len=0.7                                    # 색상 바 길이
        ),
        line=dict(width=1, color='white')              # 버블 테두리: 흰색
    ),
    text=latest_filtered['location'],                  # 국가명
    customdata=np.stack((
        latest_filtered['population'] / 1000000,       # 인구 (백만 단위)
        latest_filtered['total_deaths_thousands']      # 총 사망자 (천 단위)
    ), axis=-1),
    hovertemplate='<b>%{text}</b><br>' +
                  '백신 접종률: %{x:.1f}%<br>' +
                  '백만명당 사망자: %{y:.1f}명<br>' +
                  '인구: %{customdata[0]:.1f}백만명<br>' +
                  '총 사망자: %{customdata[1]:.1f}천명<extra></extra>'
))

# 레이아웃 설정
fig.update_layout(
    title={
        "text": "유럽 COVID-19: 백신 접종률 vs 사망률 (인구 기준, 2024)<br>" +
                "<span style='font-size: 14px'>버블 크기 = 인구 | 색상 = 사망률</span>",
        "x": 0.5,
        "xanchor": "center"
    },
    xaxis_title="백신 접종률 (%)",
    yaxis_title="백만명당 총 사망자",
    width=1200,
    height=700,
    hovermode='closest',
    plot_bgcolor='rgba(240,240,240,0.5)',
    showlegend=False
)

# X축 설정
fig.update_xaxes(
    gridcolor='white',
    range=[0, max(latest_filtered['vaccination_rate']) * 1.1]
)

# Y축 설정
fig.update_yaxes(
    gridcolor='white',
    range=[0, max(latest_filtered['total_deaths_per_million']) * 1.1]
)

# 주요 국가 라벨 추가
top_countries = ['Germany', 'France', 'Italy', 'Spain', 'Poland', 'Romania', 'Netherlands']
country_names_kr = {
    'Germany': '독일',
    'France': '프랑스',
    'Italy': '이탈리아',
    'Spain': '스페인',
    'Poland': '폴란드',
    'Romania': '루마니아',
    'Netherlands': '네덜란드'
}

annotations = []

for country in top_countries:
    country_data = latest_filtered[latest_filtered['location'] == country]
    if len(country_data) > 0:
        annotations.append(dict(
            x=country_data['vaccination_rate'].values[0],
            y=country_data['total_deaths_per_million'].values[0],
            text=country_names_kr.get(country, country),
            showarrow=True,
            arrowhead=2,
            arrowsize=1,
            arrowwidth=1,
            arrowcolor='rgba(0,0,0,0.4)',
            ax=20,
            ay=-30,
            font=dict(size=11, color='black'),
            bgcolor='rgba(255,255,255,0.8)',
            borderpad=2
        ))

fig.update_layout(annotations=annotations)

# HTML 파일로 저장
fig.write_html("Europe-COVID-19-bubble.html")

# 또는 바로 표시하려면 아래 주석 해제
# fig.show()

print("버블 차트 생성 완료!")
print("브라우저에서 '유럽_버블차트.html' 파일을 열어 확인하세요.")
