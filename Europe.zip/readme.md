europe_covid_latest.csv 사용된 천처리 데이터
Europe-COVID-19-bubble 백신 접종률과 사망자의 관계

covid_analysis_prepared.csv 사용된 천처리 데이터
Europe-COVID-19-Enhanced 유럽의 백신 접종 빨간색 마커와 다른 국가의 회색마커의 시계열 비교군 분석

