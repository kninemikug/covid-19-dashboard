import pandas as pd
import numpy as np

# 데이터 로드
df = pd.read_csv('covid_daily_full.csv')

# 유럽 대륙 필터링
europe_df = df[df['continent'] == 'Europe'].copy()

# 필요한 컬럼 선택: 백신 접종 및 사망률 관련 주요 변수
columns_to_keep = [
    'iso_code', 'continent', 'location', 'date',
    'total_deaths', 'new_deaths', 'total_deaths_per_million', 'new_deaths_per_million',
    'total_vaccinations', 'new_vaccinations', 'people_vaccinated', 'people_fully_vaccinated',
    'total_vaccinations_per_hundred', 'people_vaccinated_per_hundred', 
    'people_fully_vaccinated_per_hundred', 'population'
]

# 존재하는 컬럼만 선택
available_columns = [col for col in columns_to_keep if col in europe_df.columns]
processed_df = europe_df[available_columns].copy()

# 날짜 형식 변환
processed_df['date'] = pd.to_datetime(processed_df['date'])

# 날짜 순 정렬 (중요: ffill을 위해 필수)
processed_df = processed_df.sort_values(['location', 'date']).reset_index(drop=True)

# 결측치 처리: 누적 데이터는 forward fill 사용 (수정된 방식)
cumulative_cols = [col for col in processed_df.columns if 'total' in col.lower()]
for col in cumulative_cols:
    if col in processed_df.columns:
        processed_df[col] = processed_df.groupby('location')[col].ffill()

# 인구 데이터는 국가별 최빈값 사용
if 'population' in processed_df.columns:
    processed_df['population'] = processed_df.groupby('location')['population'].transform(
        lambda x: x.ffill().bfill()
    )

# 백신 접종률 계산 (인구 대비 백분율)
if 'people_vaccinated' in processed_df.columns and 'population' in processed_df.columns:
    processed_df['vaccination_rate'] = (
        processed_df['people_vaccinated'] / processed_df['population'] * 100
    )

if 'people_fully_vaccinated' in processed_df.columns and 'population' in processed_df.columns:
    processed_df['full_vaccination_rate'] = (
        processed_df['people_fully_vaccinated'] / processed_df['population'] * 100
    )

# 치명률(Case Fatality Rate) 계산
if 'total_cases' in processed_df.columns and 'total_deaths' in processed_df.columns:
    processed_df['case_fatality_rate'] = np.where(
        processed_df['total_cases'] > 0,
        (processed_df['total_deaths'] / processed_df['total_cases'] * 100),
        0
    )

# 이상치 제거: 음수 값을 NaN으로 처리
numeric_cols = processed_df.select_dtypes(include=[np.number]).columns
for col in numeric_cols:
    processed_df.loc[processed_df[col] < 0, col] = np.nan

# 국가별 최신 데이터 추출
latest_data = processed_df.sort_values('date').groupby('location').tail(1).reset_index(drop=True)

# 시계열 데이터: 월별 집계
processed_df['year_month'] = processed_df['date'].dt.to_period('M')
monthly_agg = processed_df.groupby(['location', 'year_month']).agg({
    'new_deaths': 'sum',
    'new_deaths_per_million': 'mean',
    'vaccination_rate': 'last',
    'full_vaccination_rate': 'last',
    'population': 'first'
}).reset_index()

monthly_agg['year_month'] = monthly_agg['year_month'].astype(str)

# 결과 저장
processed_df.to_csv('europe_covid_processed.csv', index=False)
latest_data.to_csv('europe_covid_latest.csv', index=False)
monthly_agg.to_csv('europe_covid_monthly.csv', index=False)

print(f"전처리 완료:")
print(f"- 전체 레코드 수: {len(processed_df):,}")
print(f"- 국가 수: {processed_df['location'].nunique()}")
print(f"- 기간: {processed_df['date'].min()} ~ {processed_df['date'].max()}")
print(f"\n결측치 비율 (%):")
print((processed_df.isnull().sum() / len(processed_df) * 100).round(2))
