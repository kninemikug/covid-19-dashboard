import pandas as pd
import plotly.express as px
import numpy as np

print("=== COVID-19 유럽 방역 성과 분석 (개선 버전) ===\n")

viz_data = pd.read_csv('covid_analysis_prepared.csv')
print(f"데이터 로딩 완료: {len(viz_data):,}건")
print(f"유럽 국가 수: {viz_data[viz_data['Region_Group'] == 'Europe (EURO)']['Country'].nunique()}개국\n")

euro_data = viz_data[viz_data['Region_Group'] == 'Europe (EURO)'].copy()
other_data = viz_data[viz_data['Region_Group'] != 'Europe (EURO)'].copy()

euro_data['Display_Name'] = euro_data['Country']
other_data['Display_Name'] = ''

viz_data_enhanced = pd.concat([euro_data, other_data], ignore_index=True)
viz_data_enhanced = viz_data_enhanced.sort_values('Year_Month')

print("시각화 생성 중...")

fig = px.scatter(
    viz_data_enhanced,
    x='Vaccination_Rate',
    y='CFR',
    animation_frame='Year_Month',
    animation_group='Country',
    color='Region_Group',
    size='Cumulative_cases',
    size_max=45,
    text='Display_Name',
    hover_name='Country',
    hover_data={
        'Vaccination_Rate': ':.1f',
        'CFR': ':.2f',
        'New_cases': ':,',
        'New_deaths': ':,',
        'Cumulative_cases': ':,',
        'Region_Group': True,
        'Display_Name': False
    },
    log_y=True,
    color_discrete_map={
        'Europe (EURO)': '#FF4444',
        'Other (AFRO)': '#E8E8E8',
        'Other (AMRO)': '#D0D0D0',
        'Other (EMRO)': '#B8B8B8',
        'Other (SEARO)': '#A0A0A0',
        'Other (WPRO)': '#888888'
    },
    title='COVID-19 방역 성과 비교: 유럽 51개국의 백신 접종률과 치명률 추이 (2021-2023)<br><sub>애니메이션으로 확인하는 시간대별 방역 효과 - 유럽 국가명 표시</sub>',
    labels={
        'Vaccination_Rate': '백신 기초 접종 완료율 (%)',
        'CFR': '치명률 (Case Fatality Rate, %) - 로그 스케일',
        'Region_Group': 'WHO 지역',
        'Cumulative_cases': '누적 확진자 수'
    },
    range_x=[-2, 107],
    range_y=[0.008, 120]
)

fig.update_traces(
    marker=dict(
        opacity=0.75,
        line=dict(width=1.2, color='white')
    ),
    textposition='top center',
    textfont=dict(
        size=8,
        color='black',
        family='Arial'
    ),
    selector=dict(mode='markers+text')
)

fig.update_layout(
    font=dict(size=13, family='Arial'),
    width=1600,
    height=900,
    template='plotly_white',
    xaxis=dict(
        gridcolor='#E0E0E0',
        showgrid=True,
        zeroline=False,
        range=[-2, 107]
    ),
    yaxis=dict(
        gridcolor='#E0E0E0',
        showgrid=True,
        zeroline=False,
        range=[np.log10(0.008), np.log10(120)]
    ),
    legend=dict(
        title=dict(text='<b>WHO 지역</b>', font=dict(size=14)),
        yanchor="top",
        y=0.98,
        xanchor="left",
        x=0.01,
        bgcolor='rgba(255,255,255,0.9)',
        bordercolor='gray',
        borderwidth=1,
        font=dict(size=12)
    ),
    hovermode='closest',
    plot_bgcolor='white',
    paper_bgcolor='white'
)

for frame in fig.frames:
    for trace in frame.data:
        if hasattr(trace, 'marker'):
            trace.marker.opacity = 0.75
            trace.marker.line = dict(width=1.2, color='white')
        if hasattr(trace, 'textfont'):
            trace.textfont = dict(size=8, color='black', family='Arial')
        trace.textposition = 'top center'

print("✓ 시각화 생성 완료\n")

print("=== 주요 개선사항 ===")
print("1. 유럽 51개국 모든 국가명을 그래프에 직접 표시")
print("2. 기타 지역 국가는 이름 숨김 처리 (유럽 강조)")
print("3. 마커 크기 조정 (size_max=45) 및 투명도 최적화")
print("4. 텍스트 크기 8pt로 가독성 향상")
print("5. 그래프 크기 확대 (1600x900)")
print("6. 배경색 및 그리드 최적화\n")

print("브라우저에서 그래프를 확인하세요...")
fig.show()

html_file = 'Europe-COVID-19-Enhanced.html'
fig.write_html(html_file)
print(f"\n✅ HTML 파일 저장 완료: {html_file}")
